from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import *
from django import forms
from django.db import models
from .models import *
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User, Group
from django.contrib.auth import login
from django.contrib import messages
from groups_and_permissions import *


def index(request):
    return HttpResponse('Information Page')



def students(request):
    params = {}
    form = StudentInfo()
    params['msg'] = {'Please input student information.'}

    if request.method == 'POST':
        params['msg']= 'request method accepted'
        form = StudentInfo(request.POST)

        if form.is_valid():
            params['firstname'] = form.cleaned_data['firstname']
            params['lastname'] = form.cleaned_data['lastname']
            params['major'] = form.cleaned_data['major']
            params['classification'] = form.cleaned_data['classification']
            params['status'] = form.cleaned_data['status']
            params['email'] = form.cleaned_data['email']
            params['username']= form.cleaned_data['username']
            params['password']= form.cleaned_data['password']
            username_resp = studentSubmission.objects.filter(username=params['username'])
            email_resp = studentSubmission.objects.filter(email=params['email'])
            user_resp = User.objects.filter(username=params['username'])
            if not username_resp.exists() and not user_resp.exists():
                if not email_resp.exists():
                    user = User.objects.create_user(params['username'], params['email'], params['password'])
                    student_add(user)
                    user.first_name = params['firstname']
                    user.last_name = params['lastname']
                    user.save()
                    newsubmission = studentSubmission(firstname=params['firstname'],lastname=params['lastname'],\
                                                  major=params['major'],classification=params['classification'],\
                                                  status=params['status'], email=params['email'],\
                                                  username=params['username'], password=['password'])
                    if user and newsubmission.save():
                        messages.add_message(request, messages.INFO, "Submission received and user create.")
                        params['obj']= newsubmission
                else:
                     messages.add_message(request, messages.INFO, 'Email already exists')
            else:
               messages.add_message(request, messages.INFO, 'Username already exists')
                
        else:
            params['msg']= 'Submission Error: Please review information.'
            
    else:
        params['msg']= 'no request method'
    params['form'] = form        
    return render(request, 'students/studentinfo.html', params)

def faculty(request):
    #return HttpResponse('Please input faculty information.')
    params = {}
    form = FacultyInfo()
    params['msg'] = {'Please input student information.'}
    if request.method == 'POST':
        params['msg']= 'request method accepted'
        form = FacultyInfo(request.POST)
        if form.is_valid():
            params['msg'] = 'Information Submitted'
            params['firstname'] = form.cleaned_data['firstname']
            params['lastname'] = form.cleaned_data['lastname']
            params['major'] = form.cleaned_data['major']
            params['phonenum'] = form.cleaned_data['phonenum']
            params['email'] = form.cleaned_data['email']
            params['username']= form.cleaned_data['username']
            params['password']= form.cleaned_data['password']
            username_resp = facultySubmission.objects.filter(username=params['username'])
            email_resp = facultySubmission.objects.filter(email=params['email'])
            user_resp = User.objects.filter(username=params['username'])
            major_resp = submitMajor.objects.filter(major=params['major'])
            if not username_resp.exists() and not user_resp.exists():
                if not email_resp.exists():
                    user = User.objects.create_user(params['username'], params['email'], params['password'])
                    faculty_add(user)
                    user.is_staff = True 
                    user.first_name = params['firstname']
                    user.last_name = params['lastname']
                    user.save()
                    newsubmission = facultySubmission(firstname=params['firstname'], lastname=params['lastname'],\
                                                      major=params['major'], phonenum=params['phonenum'],\
                                                      email=params['email'], username=params['username'],\
                                                      password=['password'])
                    if user and newsubmission.save():
                        params['msg'] = 'new submission saved.'
                        params['obj']= newsubmission
                    if not major_resp.exists():
                        newmajor = submitMajor(major=params['major'], facultyfirst=params['firstname'], facultylast=['lastname'], email=params['email'])
                        if newmajor.save():
                            messages.add_message(request, messages.INFO, 'Major Does Not Exist: New major created.')
                    else:
                        messages.add_message(request, messages.INFO, 'Faculty added to major.')
                else:
                    messages.add_message(request, messages.INFO, 'Email already exists')
            else:
                messages.add_message(request, messages.INFO, 'Username already exists')
   
        else:
            params['msg']= 'Submission Error: Please review information.'
    else:
        params['msg']= 'no request method'
    params['form'] = form
    return render(request, 'faculty/facultyinfo.html', params)

@login_required
def studentsubmissions(request):
    params = {}
    info = studentSubmission.objects.filter()
    params['info']= info
    return render(request, 'students/studentsubmissions.html', params)

@login_required
def viewStudent(request, user):
    params = {}
    info = studentSubmission.objects.filter(username=user)
    params['info']= info
    return render(request, 'students/viewStudent.html', params)

@login_required
def facultysubmissions(request):
    params = {}
    info = facultySubmission.objects.filter()
    params['info']= info
    return render(request, 'faculty/facultysubmissions.html', params)

@login_required
def viewFaculty(request, user):
    params = {}
    info = facultySubmission.objects.filter(username=user)
    courses = submitCourse.objects.filter(user=user)
    params['courses']= courses
    params['info']= info
    return render(request, 'faculty/viewFaculty.html', params)

@login_required
def coursesubmissions(request):
    params = {}
    info = submitCourse.objects.filter()
    params['info'] = info
    return render(request, 'students/coursesubmissions.html', params)

@login_required
def viewCourse(request, name):
    params = {}
    info_resp = submitCourse.objects.filter(coursename=name)
    students_resp = submitRegister.objects.filter(courseoption=name)
    
    if not info_resp.exists():
        messages.add_message(request, messages.INFO, "Course Information Not Available")
        return redirect('app:coursesubmissions')
    
    else:
        params['result'] = info_resp
        if students_resp.exists():
            messages.add_message(request, messages.INFO, "Students Registered")
            params['students'] = students_resp
    return render(request, 'students/viewCourse.html', params)

@user_passes_test(in_group_faculty)
#@login_required
def createMajor(request):
    params = {}
    params['form'] = MajorForm()
    if request.method == 'POST':
        form = MajorForm(request.POST)
        if form.is_valid():
            params['msg'] = "Input New Major Data"
            params['major'] = form.cleaned_data['major']
            params['facultyfirst']= form.cleaned_data['facultyfirst']
            params['facultylast']= form.cleaned_data['facultylast']
            params['email']= form.cleaned_data['email']
            newmajor = submitMajor(major=params['major'], facultyfirst=params['facultyfirst'], facultylast=params['facultylast'], email=params['email'])
            newmajor.save()
        else:
            params['msg']= "Submission Error"
    return render(request, 'faculty/createMajor.html', params)

@user_passes_test(in_group_faculty)
#@login_required
def createCourse(request):
    params = {}
    form = CourseForm()
    params['username'] = request.user.username
    if request.method == 'POST':
        params['msg'] = "Request methos is POST"
        form = CourseForm(request.POST)
        if form.is_valid():
            params['msg'] = "Input New Course Information"
            params['coursename'] = form.cleaned_data['coursename']
            params['major'] = form.cleaned_data['major']
            params['datetime'] = form.cleaned_data['datetime']
            params['faculty firstname']= form.cleaned_data['facultyfirst']
            params['faculty lastname'] = form.cleaned_data['facultylast']
            params['description'] = form.cleaned_data['description']
            newcourse = submitCourse(coursename=params['coursename'], major=params['major'], facultyfirst=params['faculty firstname'], facultylast=params['faculty lastname'], datetime=params['datetime'], description=params['description'], user=params['username'] )
            newcourse.save()
        else:
            params['msg']= "Submission Error"
    params['form'] = CourseForm()
    return render(request, 'faculty/createCourse.html', params)

#@login_required
@user_passes_test(in_group_student)
def courseRegister(request):
    params = {}
    params['username'] = request.user.username
    userinfo = studentSubmission.objects.get(username=params['username'])
    params['usermajor'] = userinfo.major
    params['options'] = submitCourse.objects.filter(major=params['usermajor'])
    course_choices = []

    for item in params['options']:
        params['coursename'] = item.coursename
        params['datetime'] = item.datetime
        params['description'] = item.description
        choice = "%s %s %s" % (params['coursename'], params['datetime'], params['description'])
        course_choices.append((choice, choice))
    params["course_choices"]= course_choices
    form = RegisterForm()    
    form.fields['courseoptions'].choices = course_choices
   
    if request.method == "POST":
        form = RegisterForm(request.POST)
        
        if form.is_valid():
            params['courseoption']= form.cleaned_data['courseoptions']
            user_resp = submitRegister.objects.filter(user=params['username'], courseoption=params['courseoptions'])

            if user_resp.exists():
                messages.add_message(request, messages.INFO, "Student Already Registered For Course")
                return redirect('app:courseRegister')

            else:    
                newregister = submitRegister(courseoption=params['courseoption'], user=params['username'])
                if user_resp.exists():
                    messages.add_message(request, messages.INFO, "Registration Complete!")
        else:
            messages.add_message(request, messages.INFO, "Form Not Valid")
            return redirect('app:courseRegister')
    params['form']= form
    return render(request, 'students/courseRegister.html', params)
