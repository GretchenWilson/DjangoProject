from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^students/$', views.students, name='students'),
    url(r'^faculty/$', views.faculty, name='faculty'),
    url(r'^studentsubmissions/$', views.studentsubmissions, name='studentsubmissions'),
    url(r'^viewStudent/(.+)/$', views.viewStudent, name='viewStudent'),
    url(r'^facultysubmissions/$', views.facultysubmissions, name='facultysubmissions'),
    url(r'^viewFaculty/(.+)/$', views.viewFaculty, name='viewFaculty'),
    url(r'^coursesubmissions/$', views.coursesubmissions, name='coursesubmissions'),
    url(r'^viewCourse/(.+)/$', views.viewCourse, name='viewCourse'),
    url(r'^createCourse/$', views.createCourse, name='createCourse'),
    url(r'^createMajor/$', views.createMajor, name='createMajor'),
    url(r'^courseRegister/$', views.courseRegister, name='courseRegister')
    
]
