from __future__ import unicode_literals

from django.apps import AppConfig


class StudentFacultyInputConfig(AppConfig):
    name = 'student_faculty_input'
