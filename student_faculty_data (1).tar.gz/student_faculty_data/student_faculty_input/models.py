from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User

class studentSubmission(models.Model):
    firstname = models.CharField(max_length=100)
    lastname = models.CharField(max_length=100)
    major = models.CharField(max_length=100)
    classification = models.CharField(max_length=100)
    status = models.CharField(max_length=100)
    email = models.CharField(max_length=100, unique=True, null=True)
    username = models.CharField(max_length=30, unique=True, null=True)
    password = models.CharField(max_length=20, null=True)
#    user = User.objects.create_user(email, username, password)
class facultySubmission(models.Model):
    firstname = models.CharField(max_length=100)
    lastname = models.CharField(max_length=100)
    major = models.CharField(max_length=100)
    email = models.EmailField(max_length=100, unique=True, null=True)
    phonenum = models.CharField(max_length=100)
    username = models.CharField(max_length=30, unique=True, null=True)
    password = models.CharField(max_length=20, null=True)

class submitMajor(models.Model):
    major = models.CharField(max_length=20, unique=True)
    creator = models.CharField(max_length=40)
    facultyfirst = models.CharField(max_length=40, null=True)
    facultylast = models.CharField(max_length=40, null=True)
    email = models.EmailField(max_length=50)

class submitCourse(models.Model):
    coursename = models.CharField(max_length=50, unique=True)
    major = models.CharField(max_length=50, null=True)
    facultyfirst = models.CharField(max_length=50, null=True)
    facultylast = models.CharField(max_length=50, null=True)
    datetime = models.CharField(max_length=50, null=True)
    description = models.CharField(max_length=200)
    user = models.CharField(max_length=50, null=True)

class submitRegister(models.Model):
    courseoption = models.CharField(max_length=100)
    user = models.CharField(max_length=100, null=True)
