from django import forms 
from .models import *

class StudentInfo(forms.Form):
    major_choices = []
    for entry in submitMajor.objects.all():
        option = entry.major
        major_choices.append((option, option))
    
    firstname = forms.CharField(label='First Name:', max_length=20)
    lastname = forms.CharField(label='Last Name:', max_length=20)
    major = forms.ChoiceField(choices=major_choices, widget=forms.RadioSelect) 
    class_choice = [('Freshman', 'Freshman'), ('Sophmore','Sophmore'), ('Junior', 'Junior'), ('Senior', 'Senior')]
    classification = forms.ChoiceField(widget=forms.RadioSelect, choices=class_choice)
    status_choice = [('Full Time', 'Full Time'), ('Part Time', 'Part Time')]
    status = forms.ChoiceField(widget=forms.RadioSelect, choices=status_choice )
    email = forms.EmailField(label='Email:', max_length=30)
    username = forms.CharField(label='Username:', max_length=30)
    password = forms.CharField(widget=forms.PasswordInput, label='Password:', max_length=30)

class FacultyInfo(forms.Form):
    firstname = forms.CharField(label='First Name:', max_length=20)
    lastname = forms.CharField(label='Last Name:', max_length=20)
    major = forms.CharField(label='Major:', max_length=30)
    email = forms.EmailField(label='Email:', max_length=30)
    phonenum = forms.CharField(label='Phone Number:', max_length=30)
    username = forms.CharField(label='Username:', max_length=30)
    password = forms.CharField(widget=forms.PasswordInput, label='Password:', max_length=30)


class MajorForm(forms.Form):
    major = forms.CharField(max_length=20)
    facultyfirst = forms.CharField(label='Faculty First Name:', max_length=40)
    facultylast = forms.CharField(label='Faculty Last Name:', max_length=40)
    email = forms.EmailField(max_length=50)

class CourseForm(forms.Form):
    major_choices = []
    for entry in submitMajor.objects.all():
        option = entry.major
        major_choices.append((option, option))
    coursename = forms.CharField(label='Course Name:', max_length=50)
    major = forms.ChoiceField(choices=major_choices, widget=forms.RadioSelect)
    facultyfirst = forms.CharField(label='Firstname of Faculty:', max_length=50)
    facultylast = forms.CharField(label='Lastname of Faculty:', max_length=50)
    datetime = forms.CharField(max_length=50)
    description = forms.CharField(widget=forms.Textarea)

class RegisterForm(forms.Form):
    courseoptions = forms.MultipleChoiceField(widget=forms.Select, initial="course name") 
#    def __init__(self, course_choice, *args, **kwargs): 
#        course_choice = kwargs.pop('course_choice', False)
#        super(RegisterForm, self).__init__(*args, **kwargs) 
#        if course_choice:
#            self.fields['courseoptions'].choices=course_choice
        




