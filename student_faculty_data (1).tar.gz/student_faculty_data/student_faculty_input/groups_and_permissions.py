from django.contrib.auth.models import User, Group

def student_add(user):
    student_group, created = Group.objects.get_or_create(name='Student')
    user.groups.add(student_group)
    return

def faculty_add(user):
    faculty_group, created = Group.objects.get_or_create(name='Faculty')
    user.groups.add(faculty_group)
    return

def in_group_faculty(user):
    if not user.is_authenticated:
        return False

    return user.is_superuser or user.groups.filter(name="Faculty").exists()

def in_group_student(user):
    if not user.is_authenticated:
        return False

    return user.is_superuser or user.groups.filter(name="Student").exists()
